#!/bin/sh
cd "$(dirname "$0")" || exit 1
if [ -x ./runtime/node ] && ./runtime/node -e '' 2>/dev/null; then
  exec ./runtime/node host.mjs --open
fi
exec node host.mjs --open
