import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createReadStream,createWriteStream} from 'node:fs';
import {access,readFile,mkdir,rename,rm,stat} from 'node:fs/promises';
import {Readable} from 'node:stream';
import {pipeline} from 'node:stream/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {networkInterfaces} from 'node:os';
import {createLanServer} from './lan-server.mjs';
const here=path.dirname(fileURLToPath(import.meta.url));
const web=path.join(here,'web');
const packageInfo=JSON.parse(await readFile(path.join(here,'media.json'),'utf8'));
async function hashFile(filepath) {
 const digest=createHash('sha256');
 for await(const block of createReadStream(filepath))digest.update(block);
 return digest.digest('hex');
}
async function getMedia([relative,expected]) {
 const output=path.join(web,relative);
 try{await access(output);if(await hashFile(output)===expected)return;}catch{}
 const url=new URL(relative,packageInfo.site);
 console.log('首次准备',relative);
 await mkdir(path.dirname(output),{recursive:true});
 const tmp=output+'.'+process.pid+'.part';
 try{
   let failure;
   for(let attempt=0;attempt<3;attempt++){
     try{
       const res=await fetch(url,{signal:AbortSignal.timeout(240000)});
       if(!res.ok)throw new Error('下载失败 '+res.status);
       await pipeline(Readable.fromWeb(res.body),createWriteStream(tmp));
       if(await hashFile(tmp)!==expected)throw new Error('文件校验失败');
       await rename(tmp,output);return;
     }catch(error){failure=error;}
   }
   throw failure;
 }finally{await rm(tmp,{force:true});}
}
try{await Promise.all(packageInfo.files.map(getMedia));}catch(error){console.error('准备游戏文件失败：'+error.message+'。请检查网络后重新启动。');process.exit(1);}
const server=createLanServer(web);
const port=Number(process.env.BVN_PORT)||8765;
server.on('error',error=>{
 if(error.code==='EADDRINUSE')server.listen(0,'0.0.0.0');
 else {console.error(error.message);process.exitCode=1;}
});
server.on('listening',()=>{
 const port=server.address().port,url='http://127.0.0.1:'+port+'/';
 console.log('本机 '+url);
 for(const entries of Object.values(networkInterfaces()))for(const ip of entries||[])if(ip.family==='IPv4'&&!ip.internal)console.log('同一网络 http://'+ip.address+':'+port+'/');
 if(process.argv.includes('--open')){
   const args=process.platform==='darwin'?['open',[url]]:process.platform==='win32'?['rundll32.exe',['url.dll,FileProtocolHandler',url]]:['xdg-open',[url]];
   const child=spawn(args[0],args[1],{detached:true,stdio:'ignore'});child.on('error',()=>{});child.unref();
 }
});
server.listen(port,'0.0.0.0');
