import http from 'node:http';
import { createReadStream } from 'node:fs';
import { stat, realpath } from 'node:fs/promises';
import { networkInterfaces } from 'node:os';
import path from 'node:path';
import { randomBytes } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const mime = { '.html':'text/html; charset=utf-8', '.mjs':'text/javascript', '.js':'text/javascript', '.css':'text/css', '.wasm':'application/wasm', '.swf':'application/x-shockwave-flash', '.png':'image/png', '.webp':'image/webp', '.svg':'image/svg+xml', '.json':'application/json', '.ico':'image/x-icon' };
const lanIPs = () => Object.values(networkInterfaces()).flat().filter(x => x && x.family === 'IPv4' && !x.internal).map(x => x.address);
const token = () => randomBytes(18).toString('hex');
function sendJSON(res, status, object) {
  res.writeHead(status, {'Content-Type':'application/json', 'Cache-Control':'no-store'});
  res.end(JSON.stringify(object));
}
async function readJSON(req) {
  let payload = '';
  for await (const block of req) {
    payload += block;
    if (payload.length > 32768) throw new Error('消息过大');
  }
  return JSON.parse(payload || '{}');
}

export function createLanServer(root) {
  const rooms = new Map();
  const members = new Map();
  function emit(member, type, body) {
    const packet = 'data: ' + JSON.stringify({type,...body}) + '\n\n';
    if (member.stream && !member.stream.destroyed) member.stream.write(packet);
    else if (member.queue.length < 120) member.queue.push(packet);
  }
  function leave(member) {
    if (!members.delete(member.secret)) return;
    const room = member.room;
    room.members.delete(member.id);
    member.stream?.end();
    if (room.host === member.id) {
      rooms.delete(room.code);
      for (const other of [...room.members.values()]) {
        emit(other, 'ended', {});
        leave(other);
      }
    } else {
      const host = room.members.get(room.host);
      if (host) emit(host,'left',{id:member.id});
    }
  }
  const heartbeat = setInterval(() => {
    for (const peer of members.values()) {
      if (peer.stream) peer.stream.write(': ping\n\n');
      else if (Date.now() - peer.disconnectedAt > 20000) leave(peer);
    }
  }, 5000);
  heartbeat.unref();
  const server = http.createServer(async(req,res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      if (url.pathname.startsWith('/__lan/')) {
        if (req.headers.origin && new URL(req.headers.origin).host !== req.headers.host) return sendJSON(res,403,{error:'来源不同'});
        if (url.pathname === '/__lan/info' && req.method === 'GET') return sendJSON(res,200,{addresses:lanIPs(),port:server.address().port});
        if (url.pathname === '/__lan/open' && req.method === 'POST') {
          const body = await readJSON(req);
          let room, role;
          if (body.code) {
            room=rooms.get(String(body.code).toUpperCase());
            if (!room) return sendJSON(res,404,{error:'房间不存在或已经关闭'});
            if (room.members.size >= 6) return sendJSON(res,409,{error:'房间人数已满'});
            role=Array.from(room.members.values()).some(p=>p.role==='guest') ? 'watch' : 'guest';
          } else {
            if (rooms.size>=128) return sendJSON(res,429,{error:'房间数量已满'});
            let code;
            do {code=randomBytes(3).toString('hex').toUpperCase();} while (rooms.has(code));
            room={code, members:new Map()}; rooms.set(code,room); role='host';
          }
          const member={room,role,secret:token(),id:randomBytes(6).toString('hex'),queue:[],stream:null,disconnectedAt:Date.now()};
          room.members.set(member.id,member);members.set(member.secret,member);
          if (role==='host') room.host=member.id;
          else emit(room.members.get(room.host),'joined',{id:member.id,role});
          return sendJSON(res,200,{code:room.code,role,host:room.host,id:member.id,secret:member.secret});
        }
        const member=members.get(url.searchParams.get('key'));
        if (!member) return sendJSON(res,403,{error:'房间连接已结束'});
        if (url.pathname==='/__lan/events' && req.method==='GET') {
          member.stream?.end(); member.stream=res;
          res.writeHead(200, {'Content-Type':'text/event-stream','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no'});
          res.write('retry: 1000\n\n');
          for (const message of member.queue.splice(0)) res.write(message);
          res.on('close',()=>{if(member.stream===res){member.stream=null;member.disconnectedAt=Date.now();}});
          return;
        }
        if (url.pathname==='/__lan/leave' && req.method==='POST') {
          leave(member); return sendJSON(res,200,{ok:true});
        }
        if (url.pathname==='/__lan/signal' && req.method==='POST') {
          const body=await readJSON(req);const to=member.room.members.get(body.to);
          if (!to || (to.role!=='host' && member.role!=='host')) return sendJSON(res,403,{error:'不在同一房间'});
          if (!['offer','answer','candidate'].includes(body.signal?.type)) return sendJSON(res,400,{error:'无效连接'});
          emit(to,'signal',{from:member.id,signal:body.signal});return sendJSON(res,200,{ok:true});
        }
        return sendJSON(res,404,{error:'接口不存在'});
      }
      if (!['GET','HEAD'].includes(req.method)) return sendJSON(res,405,{error:'无此请求方法'});
      const requested=decodeURIComponent(url.pathname);
      let filename=path.resolve(root,'.'+requested);
      if (!filename.startsWith(root+path.sep) && filename!==root) return sendJSON(res,404,{});
      const first=await stat(filename);
      if(first.isDirectory()) filename=path.join(filename,'index.html');
      filename=await realpath(filename);
      if(!filename.startsWith(root+path.sep)) return sendJSON(res,404,{});
      const info=await stat(filename);
      if (!info.isFile()) return sendJSON(res,404,{});
      res.writeHead(200,{'Content-Type':mime[path.extname(filename)] || 'application/octet-stream','Content-Length':info.size,'Cache-Control':'no-cache'});
      if(req.method==='HEAD') res.end(); else createReadStream(filename).on('error',()=>res.destroy()).pipe(res);
    } catch(error) {
      if(res.headersSent) {res.end();return;}
      sendJSON(res,error.code==='ENOENT'?404:400,{error:error.code==='ENOENT'?'文件不存在':'请求错误'});
    }
  });
  server.on('close',()=>clearInterval(heartbeat));return server;
}
if (process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  const arg=(name,fallback)=>args.includes(name)?args[args.indexOf(name)+1]:fallback;
  const root=await realpath(arg('--root',path.dirname(fileURLToPath(import.meta.url))));
  const port=Number(arg('--port',8765));
  const server=createLanServer(root);
  server.on('error',e=>{console.error('无法启动局域网服务',e.message);process.exitCode=1;});
  server.listen(port,'0.0.0.0',()=>{
    const p=server.address().port;
    console.log('本机 http://127.0.0.1:'+p+'/');
    for (const ip of lanIPs()) console.log('同一网络 http://'+ip+':'+p+'/');
  });
}
