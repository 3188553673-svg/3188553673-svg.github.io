@echo off
cd /d "%~dp0"
if exist "runtime\node.exe" (
  "runtime\node.exe" host.mjs --open
) else (
  node host.mjs --open
)
if errorlevel 1 pause
