@echo off
setlocal
cd /d "%~dp0"
set "ARENA_NODE=node"
if exist "runtime\node.exe" set "ARENA_NODE=runtime\node.exe"
"%ARENA_NODE%" -e "process.exit(+process.versions.node.split('.')[0] >= 18 ? 0 : 1)" >nul 2>nul
if errorlevel 1 (
  echo Please install Node.js 18 or later from https://nodejs.org/ and launch again.
  pause
  exit /b 1
)
"%ARENA_NODE%" server.mjs --open
if errorlevel 1 pause
