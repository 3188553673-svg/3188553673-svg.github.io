#!/bin/zsh
cd -- "${0:A:h}" || exit 1
for candidate in "./runtime/node" "${commands[node]}" "/opt/homebrew/bin/node" "/usr/local/bin/node" "$HOME/Library/Application Support/Tuanjie Cowork/bin/node"; do
  if [[ -n "$candidate" && -x "$candidate" ]] && "$candidate" -e 'process.exit(+process.versions.node.split(".")[0] < 18 ? 1 : 0)' 2>/dev/null; then
    exec "$candidate" server.mjs --open
  fi
done
print '请先安装 Node.js 18 或更高版本，然后重新双击启动游戏。'
print '下载地址：https://nodejs.org/'
read '?按回车键退出'
