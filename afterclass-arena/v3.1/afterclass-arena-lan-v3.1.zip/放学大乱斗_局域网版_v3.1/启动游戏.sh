#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
if ! command -v node >/dev/null 2>&1 || ! node -e 'process.exit(Number(process.versions.node.split(".")[0]) < 18 ? 1 : 0)'; then
  echo '请先安装 Node.js 18 或更新版本，再运行启动游戏.sh。'
  exit 1
fi
exec node server.mjs --open
