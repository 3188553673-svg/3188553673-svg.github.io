import http from 'node:http';
import { networkInterfaces } from 'node:os';
import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { extname, resolve, sep } from 'node:path';
import { randomInt, randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';
import { performance } from 'node:perf_hooks';
import ws from './vendor/ws/index.js';
import qrcode from './vendor/qrcode-generator/dist/qrcode.mjs';
import { CHARACTERS, createGame, stepGame } from './public/engine.mjs';

const { WebSocketServer } = ws;
const publicDir = fileURLToPath(new URL('./public/', import.meta.url));
const defaultPort = 8127;
const requestedPort = Number(process.env.PORT ?? defaultPort);
const hosts = new Map();
const rooms = new Map();
const version = '2.2';
const controls = ['left', 'right', 'down', 'jump', 'attack', 'skill', 'dodge'];
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.jpg': 'image/jpeg', '.woff2': 'font/woff2', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.wav': 'audio/wav' };

function netInfo() {
  const urls = [];
  for (const [name, addresses] of Object.entries(networkInterfaces())) {
    for (const nic of addresses ?? []) {
      if (nic.internal || nic.family !== 'IPv4') continue;
      const virtual = /^(utun|tun|tap|veth|virbr|docker|br-|vmnet|vboxnet|tailscale|awdl|llw)|virtual|vpn/i.test(name);
      const wireless = /^(en0|wlan\d+|wlp.*|wi-?fi.*|无线.*)$/i.test(name);
      const selfAssigned = nic.address.startsWith('169.254.');
      const weight = (virtual ? 20 : 0) + (selfAssigned ? 8 : 0) + (wireless ? 0 : 2);
      urls.push({ address: nic.address, weight });
    }
  }
  urls.sort((a, b) => a.weight - b.weight);
  const port = server.address()?.port ?? requestedPort;
  const physical = urls.filter(item => item.weight < 20);
  const reachable = physical.length ? physical : urls;
  return { app: 'afterschool-arena', version, urls: [...new Set(reachable.map(item => 'http://' + item.address + ':' + port))], port };
}

function goodHost(hostValue) {
  if (!hostValue) return false;
  try {
    const hostname = new URL('http://' + hostValue).hostname;
    return hostname === 'localhost' || hostname === '127.0.0.1' || netInfo().urls.some(url => new URL(url).hostname === hostname);
  } catch { return false; }
}

function sharedUrl(room, localIP) {
  const info = netInfo();
  const actual = info.urls.find(url => new URL(url).hostname === localIP);
  return (actual ?? info.urls[0] ?? 'http://127.0.0.1:' + info.port) + '/?room=' + room.code;
}

function sendHttp(res, status, body, type = 'text/plain; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  try {
    if (!goodHost(req.headers.host)) return sendHttp(res, 403, '请使用本机或局域网地址打开游戏');
    if (req.method !== 'GET' && req.method !== 'HEAD') return sendHttp(res, 405, 'Method not allowed');
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname === '/api/info') return sendHttp(res, 200, JSON.stringify(netInfo()), types['.json']);
    if (url.pathname === '/api/qr') {
      const room = rooms.get(url.searchParams.get('room'));
      if (!room) return sendHttp(res, 404, '房间已关闭');
      const hostAddress = url.searchParams.get('ip');
      const urlForCode = sharedUrl(room, hostAddress || req.socket.localAddress);
      if (!room.qr.has(urlForCode)) {
        const qr = qrcode(0, 'M');
        qr.addData(urlForCode, 'Byte'); qr.make();
        const dataUrl = qr.createDataURL(6, 24);
        room.qr.set(urlForCode, Buffer.from(dataUrl.split(',')[1], 'base64'));
      }
      return sendHttp(res, 200, room.qr.get(urlForCode), 'image/gif');
    }
    const decoded = decodeURIComponent(url.pathname);
    if (decoded.includes('\0') || decoded.includes('\\')) return sendHttp(res, 400, 'Invalid path');
    const file = resolve(publicDir, '.' + (decoded === '/' ? '/index.html' : decoded));
    if (!file.startsWith(resolve(publicDir) + sep)) return sendHttp(res, 404, 'Not found');
    const fileStat = await stat(file).catch(() => null);
    if (!fileStat?.isFile()) return sendHttp(res, 404, 'Not found');
    res.writeHead(200, { 'Content-Type': types[extname(file).toLowerCase()] ?? 'application/octet-stream', 'Content-Length': fileStat.size, 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
    if (req.method === 'HEAD') return res.end();
    const stream = createReadStream(file);
    stream.on('error', () => res.destroy()); res.on('close', () => stream.destroy()); stream.pipe(res);
  } catch { if (!res.headersSent) sendHttp(res, 400, 'Bad request'); else res.destroy(); }
});

const sockets = new WebSocketServer({ noServer: true, maxPayload: 4096, perMessageDeflate: false });
server.on('upgrade', (req, socket, head) => {
  const origin = req.headers.origin;
  if (req.url !== '/arena' || !goodHost(req.headers.host) || (origin && origin !== 'http://' + req.headers.host)) return socket.destroy();
  sockets.handleUpgrade(req, socket, head, clientSocket => sockets.emit('connection', clientSocket, req));
});

function send(client, msg) {
  if (client.socket.readyState === 1) client.socket.send(JSON.stringify(msg));
}

function seatsFor(room) {
  return [...room.members.values()].flatMap(member => member.seats.map((char, seat) => ({
    id: member.id + '-' + seat, clientId: member.id, seat, char, name: CHARACTERS[char].name, bot: false
  })));
}

function notifyRoom(room, notice = '') {
  const players = seatsFor(room);
  for (const client of room.members.values()) {
    const joinUrl = sharedUrl(room, client.localIP);
    const address = new URL(joinUrl).hostname;
    send(client, { type: 'room', room: { code: room.code, host: room.host, clientId: client.id, phase: room.phase, players,
      joinUrl, qrUrl: '/api/qr?room=' + room.code + '&ip=' + address, notice } });
  }
}

function returnToLobby(room, notice = '') {
  room.phase = 'lobby'; room.game = null;
  for (const member of room.members.values()) member.inputs = [];
  notifyRoom(room, notice);
}

function detach(client) {
  const room = client.room;
  if (!room) return;
  client.room = null; client.inputs = [];
  room.members.delete(client.id);
  if (!room.members.size) { rooms.delete(room.code); return; }
  const newHost = room.host === client.id;
  if (newHost) room.host = room.members.keys().next().value;
  const notice = '有玩家已离开' + (newHost ? '，房主已移交' : '');
  if (room.phase === 'lobby') notifyRoom(room, notice);
  else returnToLobby(room, notice + '，已返回房间');
}

function validateSeats(seats) {
  if (!Array.isArray(seats) || seats.length < 1 || seats.length > 2 || !seats.every(c => typeof c === 'string' && Object.hasOwn(CHARACTERS, c))) {
    throw new Error('每台设备可选择一到两名角色');
  }
}

function setSeats(client, room, seats) {
  validateSeats(seats);
  const others = seatsFor(room).filter(player => player.clientId !== client.id);
  if (others.length + seats.length > 4) throw new Error('房间最多容纳四名玩家，请减少本机人数');
  client.seats = seats;
}

function readInput(client, rows) {
  if (client.room?.phase !== 'game' || !Array.isArray(rows)) return;
  client.seats.forEach((_, seat) => {
    const row = rows[seat] ?? {};
    const input = client.inputs[seat] ??= { mask: 0, held: {}, queue: [] };
    const mask = controls.reduce((value, key, bit) => row[key] === true ? value | (1 << bit) : value, 0);
    if (mask === input.mask) return;
    input.mask = mask;
    const sample = Object.fromEntries(controls.map(key => [key, row[key] === true]));
    // A Wi-Fi burst can contain down, diagonal, forward and punch together.
    // Present genuine transitions in order, one simulation tick per sample.
    if (input.queue.length >= 14) input.queue.shift();
    input.queue.push(sample);
  });
  client.inputAt = performance.now();
}

function processCommand(client, msg) {
  if (msg.type === 'input') { readInput(client, msg.rows); return; }
  if (msg.type === 'leave') { detach(client); return; }
  if (msg.type === 'create' || msg.type === 'join') {
    if (client.room) throw new Error('请先离开当前房间');
    validateSeats(msg.seats);
    let room;
    if (msg.type === 'create') {
      let code;
      do { code = String(randomInt(100000, 1000000)); } while (rooms.has(code));
      room = { code, host: client.id, members: new Map(), phase: 'lobby', game: null, qr: new Map() };
    } else {
      room = rooms.get(String(msg.code));
      if (!room) throw new Error('找不到这个房间，请核对房间码和局域网地址');
      if (room.phase !== 'lobby') throw new Error('房间正在对战，请在返回房间后加入');
    }
    setSeats(client, room, msg.seats);
    rooms.set(room.code, room); client.room = room; room.members.set(client.id, client); notifyRoom(room);
    return;
  }
  const room = client.room;
  if (!room) throw new Error('请先加入房间');
  if (msg.type === 'seats') {
    if (room.phase !== 'lobby') throw new Error('请返回房间后再换角色');
    setSeats(client, room, msg.seats); notifyRoom(room); return;
  }
  if (room.host !== client.id) throw new Error('仅房主可以开始或结束本局');
  if (msg.type === 'lobby') { returnToLobby(room); return; }
  if (msg.type === 'start') {
    if (room.phase === 'game') return;
    const roster = seatsFor(room);
    if (roster.length < 2) throw new Error('至少需要两名玩家才能开始');
    for (const member of room.members.values()) member.inputs = [];
    room.game = createGame(roster); room.phase = 'game'; notifyRoom(room);
    broadcastGame(room);
    return;
  }
  throw new Error('未知房间操作');
}

sockets.on('connection', (socket, req) => {
  const client = { id: randomUUID().slice(0, 12), socket, localIP: req.socket.localAddress, seats: [], inputs: [], inputAt: 0, room: null, alive: true };
  hosts.set(client.id, client);
  socket.on('pong', () => { client.alive = true; });
  socket.on('message', (raw, isBinary) => {
    if (isBinary) return;
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    if (!msg || typeof msg !== 'object') return;
    try {
      processCommand(client, msg);
      if (Number.isSafeInteger(msg.seq)) send(client, { type: 'ack', seq: msg.seq });
    } catch (error) { send(client, { type: 'error', seq: msg.seq, message: error.message }); }
  });
  socket.on('close', () => { hosts.delete(client.id); detach(client); });
  socket.on('error', () => socket.terminate());
});

function broadcastGame(room) {
  const payload = JSON.stringify({ type: 'state', state: room.game });
  for (const member of room.members.values()) {
    if (member.socket.readyState !== 1) continue;
    if (member.socket.bufferedAmount > 2 * 1024 * 1024) { member.socket.terminate(); continue; }
    if (member.socket.bufferedAmount < 96 * 1024 || room.game.phase === 'over') member.socket.send(payload);
  }
}

function tickRoom(room, now) {
  const inputs = {};
  for (const client of room.members.values()) {
    client.inputs.forEach((input, i) => {
      if (now - client.inputAt >= 1200) {
        input.queue.length = 0;
        input.held = {};
        input.mask = 0;
        return;
      }
      if (input.queue.length) input.held = input.queue.shift();
      inputs[client.id + '-' + i] = input.held;
    });
  }
  stepGame(room.game, inputs);
  if (room.game.phase === 'over') {
    room.phase = 'over'; broadcastGame(room); notifyRoom(room);
  } else if (room.game.tick % 2 === 0) broadcastGame(room);
}

const frameTime = 1000 / 60;
let previous = performance.now(), accumulated = 0;
const ticker = setInterval(() => {
  const now = performance.now();
  accumulated = Math.min(accumulated + now - previous, frameTime * 5); previous = now;
  while (accumulated >= frameTime) {
    for (const room of rooms.values()) if (room.phase === 'game') tickRoom(room, now);
    accumulated -= frameTime;
  }
}, 6);
ticker.unref();

setInterval(() => {
  for (const client of hosts.values()) {
    if (!client.alive) { client.socket.terminate(); continue; }
    client.alive = false; client.socket.ping();
  }
}, 12000).unref();

function openBrowser(url) {
  const [command, ...args] = process.platform === 'darwin' ? ['open', url] :
    process.platform === 'win32' ? ['rundll32.exe', 'url.dll,FileProtocolHandler', url] : ['xdg-open', url];
  const proc = spawn(command, args, { detached: true, stdio: 'ignore' }); proc.on('error', () => {}); proc.unref();
}

const openRequested = process.argv.includes('--open');
server.on('error', async error => {
  if (error.code === 'EADDRINUSE' && openRequested) {
    const target = 'http://127.0.0.1:' + requestedPort;
    try {
      const info = await fetch(target + '/api/info', { signal: AbortSignal.timeout(1500) }).then(response => response.json());
      if (info.app === 'afterschool-arena' && info.version === version) { openBrowser(target); process.exit(0); }
    } catch {}
    server.listen(0, '0.0.0.0'); return;
  }
  console.error('启动失败：' + error.message); process.exit(1);
});

server.on('listening', () => {
  const info = netInfo();
  const url = 'http://127.0.0.1:' + info.port;
  console.log('放学大乱斗 · 本机入口 ' + url);
  for (const lan of info.urls) console.log('局域网地址 ' + lan);
  console.log('同一 Wi-Fi 的朋友可从房间内扫码加入。关闭服务请按 Ctrl+C。');
  if (openRequested) openBrowser(url);
});
server.listen(requestedPort, '0.0.0.0');
